function check() {      //this function contains a set of statements that performs a task or calculates a value
   var c=0;   //var is a keyword that lets javascrpt know the user is declaring a variable. c is 0 at this point.
   var q1=document.quiz.question1.value;
   var q2=document.quiz.question2.value;
   var q3=document.quiz.question3.value;
   var q4=document.quiz.question4.value;
   var q5=document.quiz.question5.value;
   var result=document.getElementById('result');
   var quiz=document.getElementById("quiz");
   if (q1=="right") {c++}    // if statement. it is used to dpecify a block of code to be executed. if a specified cobdition is true, else is used to specify a block of code to be executed. 
   if (q2=="right") {c++} // if the user anwers correctly, one is added to the value of c.
   if (q3=="right") {c++}
   if (q4=="right") {c++}
   if (q5=="right") {c++}
   quiz.style.display="none";

   if (c<=4) {
     result.textContent="Your result is "+c+" . Do better next time . The correct answers are : 1.B,  2.B, 3.A,4.D,5.C" // if the user gets a score less than or equal to 4, the javascript asks the user to do better and shows the user the correct answers.
    
   }
   else{
   result.textContent="Your result is "+c+" . well done. keep it up!." //if the user answers all the questions corrrectly, the javascript congratulates the user.
   }
}
